# AMIPARKN 3D website deployment

This project is built with Vite. Do not publish the source `index.html` directly from the `main` branch root.

1. Copy the contents of this folder into the root of the `CoCoBra49/amiparkn-privacy` repository, replacing the old `index.html` and adding `src/`, `package.json`, `package-lock.json`, `vite.config.js`, and `.github/workflows/deploy.yml`.
2. Keep the existing `impressum.html`, `privacy.html`, `site.css`, and `site.js` files. The workflow copies the legal pages and shared assets into the built output.
3. In GitHub: Settings → Pages → Build and deployment → Source, select **GitHub Actions**.
4. Commit and push to `main`. The workflow installs dependencies, builds the 3D site, and deploys the generated `dist/` folder.

The legal pages remain available at `/impressum.html` and `/privacy.html`.
